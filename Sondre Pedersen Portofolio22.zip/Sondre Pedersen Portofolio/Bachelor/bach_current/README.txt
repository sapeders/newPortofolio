Dette er githuben tli Bachelorgruppe 26 ved H�yskolen i �stfold 2018. Denne giten skal inneholde den n�v�rende situasjonen for omr�de p� gr�lum. Smart parkering.

Hupe.no