﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class parkingSpotSelector : MonoBehaviour {
    public List<Transform> parkeringspots = new List<Transform>();

    public void sendToFreeParkeringSpace(NewCarEngine ce)
    {
        if (!ce.doHasPath2() && parkeringspots.Count > 0) {

            while(true)
            {
                int i = UnityEngine.Random.Range(0, parkeringspots.Count);
                    Path test = parkeringspots[i].GetComponent<Path>();
                    if (!test.taken)
                    {
                        ce.setPath2(parkeringspots[i]);
                        parkeringspots.RemoveAt(i);
                        Debug.Log("Denne er viktig: " + parkeringspots.Count);
                        test.taken = true;
                        Debug.Log(ce.name + "Parkerer på ->" + test.name);
                        break;
                    }
            }
        }
    }

}
