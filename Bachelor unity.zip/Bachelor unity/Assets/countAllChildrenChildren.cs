﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class countAllChildrenChildren : MonoBehaviour {
    public int childrensChildren;
	void Update () {
        foreach (Transform t in transform)
        {
            childrensChildren += t.childCount;
        }
	}
}
