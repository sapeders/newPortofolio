﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class NewCarEngine : MonoBehaviour
{

    public Transform path;
    public Transform path1;
    private Transform path2;
    
    public float maxSteerAngle = 45;
    public float turnSpeed = 5;
    public WheelCollider wheelFL;
    public WheelCollider wheelFR;
    public WheelCollider wheelRL;
    public WheelCollider wheelRR;
    public float maxMotorTorque = 40;
    public float maxBrakeTorque = 1500;
    public float currentSpeed;
    private float maxSpeed = 7f;
    public Vector3 centerOfMass;
    public bool isBraking = false;
    public Texture2D textureNormal;
    public Texture2D textureBraking;    
    public Renderer carRenderer;

    public static bool park;
    public bool driving;
    public bool hasPath2;

    [Header("Sensors")]
    public float sensorLength = 7f;
    public Vector3 frontSensorPosition = new Vector3(0f, 0.2f, 0.5f);
    public float frontSideSensorPosition = 0.3f;


    private List<Transform> nodes;
    private int currectNode = 0;
    private bool braking = false;

    public Rigidbody rb;


    private void Awake()
    {
        GetComponent<Rigidbody>().centerOfMass = centerOfMass;

        park = false;
        driving = true;
        hasPath2 = false;


        Transform[] pathTransforms = path.GetComponentsInChildren<Transform>();
        Transform[] path1Transforms = path1.GetComponentsInChildren<Transform>();
        
        
        nodes = new List<Transform>();

        for (int i = 0; i < pathTransforms.Length; i++)
        {
            if (pathTransforms[i] != path.transform)
            {
                nodes.Add(pathTransforms[i]);
            }
        }

        for (int i = 0; i < path1Transforms.Length; i++)
        {
            if (path1Transforms[i] != path1.transform)
            {
                nodes.Add(path1Transforms[i]);
            }
        }
        path1.GetComponentInChildren<parkingSpotSelector>().sendToFreeParkeringSpace(this);
        Transform[] path2Transforms = path2.GetComponentsInChildren<Transform>();

        for (int i = 0; i < path2Transforms.Length; i++)
        {
            if (path2Transforms[i] != path2.transform)
            {
                nodes.Add(path2Transforms[i]);
            }
        }


    }

    private void FixedUpdate()
    {
        if (driving)
        {
            Sensors();
            ApplySteer();
            Drive();
            CheckWaypointDistance();
            Braking();
        }
        else
        {
            this.gameObject.SetActive(false);
        }
    }

    private void Sensors()
    {
        RaycastHit hit;
        Vector3 sensorStartPos = transform.position;
        sensorStartPos += transform.forward * frontSensorPosition.z;
        sensorStartPos += transform.up * frontSensorPosition.y;
        braking = false;



        //Front center sensor
        if (Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }

        }


        // Front right sensor
        sensorStartPos += transform.right * frontSideSensorPosition * 2;
        if (Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }
        }


        // Front left sensor
        sensorStartPos -= transform.right * frontSideSensorPosition * 2;
        if (Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }
        }

        if (braking)
        {
            isBraking = true;
        }
        else
        {
            isBraking = false;
        }


    }

    private void ApplySteer()
    {
        /* if (brake)
             isBraking = true;*/

        Vector3 relativeVector = transform.InverseTransformPoint(nodes[currectNode].position);
        float newSteer = (relativeVector.x / relativeVector.magnitude) * maxSteerAngle;
        wheelFL.steerAngle = newSteer;
        wheelFR.steerAngle = newSteer;
    }

    private void Drive()
    {
        currentSpeed = 2 * Mathf.PI * wheelFL.radius * wheelFL.rpm * 60 / 1000;

        if (currentSpeed < maxSpeed && !isBraking)
        {
            wheelFL.motorTorque = maxMotorTorque;
            wheelFR.motorTorque = maxMotorTorque;
        }
        else
        {
            wheelFL.motorTorque = 0;
            wheelFR.motorTorque = 0;
        }
    }

    private void CheckWaypointDistance()
    {
        if (Vector3.Distance(transform.position, nodes[currectNode].position) < 1f)
        {
            if (currectNode == nodes.Count - 1)
            {
                currectNode = 0;
            }
            else
            {
                currectNode++;
            }
        }
    }

    private void Braking()
    {
        if (isBraking)
        {
            carRenderer.material.mainTexture = textureBraking;
            wheelRL.brakeTorque = maxBrakeTorque;
            wheelRR.brakeTorque = maxBrakeTorque;
            if (currentSpeed > 3 && !park)
            {
                rb.drag = 1;
            }
                
        }
        else
        {
            carRenderer.material.mainTexture = textureNormal;
            wheelRL.brakeTorque = 0;
            wheelRR.brakeTorque = 0;
            if (currentSpeed < 3 && !park)
            {
                rb.drag = 0;
            }
        }
        if (currentSpeed < 1 && isBraking && !park)
        {
            currentSpeed = 1;
        }
    }
    
    public void setPath2(Transform np)
    {
        path2 = np;
        hasPath2 = true;
    }
    public void setDrivingFalse()
    {
        driving = false;
    }
    public bool doHasPath2()
    {
        return hasPath2;
    }

}
