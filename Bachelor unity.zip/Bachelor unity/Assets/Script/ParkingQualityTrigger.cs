﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class ParkingQualityTrigger : MonoBehaviour {

    
	// Use this for initialization
	void Start () {
		
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Car")
        {
            other.GetComponent<NewCarEngine>().maxMotorTorque = 0f;
            other.GetComponent<NewCarEngine>().rb.drag = 10f;
        }
    }

    void OnTriggerStay(Collider other)
    {
        if(other.tag == "Car")
        {
            if (other.GetComponent<NewCarEngine>().currentSpeed < 0)
            {
                other.GetComponent<NewCarEngine>().setDrivingFalse();
            }
        }
        
    }

    


	// Update is called once per frame
	void Update () {
        
	}
}
