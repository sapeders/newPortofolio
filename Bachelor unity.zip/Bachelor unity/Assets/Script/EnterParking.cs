﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnterParking : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Car")
        {
            other.GetComponent<NewCarEngine>().maxMotorTorque = 35;
            other.GetComponent<NewCarEngine>().maxBrakeTorque = 600;
            other.GetComponent<NewCarEngine>().sensorLength = 4;
        }
    }

}
