﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeFix : MonoBehaviour {
    public float timeScale = 5f;
	// Use this for initialization
	void Start () {
        Time.timeScale = timeScale;
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKey(KeyCode.KeypadPlus))
        {
            if (timeScale <= 20.0f )
            {
                timeScale += 0.2f;
                updateTimeScale();
            }
        }
        if (Input.GetKey(KeyCode.KeypadMinus))
        {
            if (timeScale >= 0.4f)
            {
                timeScale -= 0.2f;
                updateTimeScale();
            }
        }
    }
    void updateTimeScale()
    {
        Time.timeScale = timeScale;
    }
}
