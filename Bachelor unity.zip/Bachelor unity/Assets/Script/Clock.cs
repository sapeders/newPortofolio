﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class Clock : MonoBehaviour
{

    private Text textBlock;
    // Use this for initialization
    void Start()
    {
        textBlock = GetComponent<Text>();
        Time.timeScale = 10;
    }

    // Update is called once per frame
    void Update()
    {
        string hour = "00", minute = "00";
        double time = Time.timeSinceLevelLoad;
        if (time < 3600)
        {
            if (time < 600)
            {
                minute = "0";
                minute += ((int)(time / 60)).ToString();
            }
            else
            {
                minute = ((int)(time / 60)).ToString();
            }
            hour = "07";
        }
        else if (time < 7200)
        {
            if ((time - 3600) < 600)
            {
                minute = "0";
                minute += ((int)(time / 60)).ToString();
            }
            else
            {
                minute = ((int)(time / 60)).ToString();
            }
            hour = "08";
            minute = ((int)(time - 3600) / 60).ToString();
        }
        else if (time < 10800)
        {
            if ((time - 7200) < 600)
            {
                minute = "0";
                minute = ((int)(time / 60)).ToString();
            }
            else
            {
                minute += ((int)(time / 60)).ToString();
            }
            hour = "09";
            minute = ((int)(time - 7200) / 60).ToString();
        }
        else if (time >= 10800)
        {
            hour = "10";
            minute = "00";
            Time.timeScale = 0;
        }


        textBlock.text = hour + ":" + minute;
    }

    string LeadingZero(int n)
    {
        return n.ToString().PadLeft(2, '0');
    }
}
