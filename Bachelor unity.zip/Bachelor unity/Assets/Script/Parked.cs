﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parked : MonoBehaviour {

    public bool parked;
    private GameObject parkingSpot;
    private Renderer parkingRender;

    // Use this for initialization
    void Start () {
        parked = false;
        parkingRender = GetComponent<MeshRenderer>();
    }
	
	// Update is called once per frame
	void Update () {
        /*
		if(parked == true)
        {
            NewCarEngine.park = true;
        }
        */
	}


    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Car")
        {
            parked = true;
            NewCarEngine.park = true;
            parkingRender.GetComponent<Renderer>().material.color = Color.red;
            //Debug.Log(this.gameObject + " The car is parked");
        }
    }

}
