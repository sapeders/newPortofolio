﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewPath : MonoBehaviour {

    [SerializeField] Transform parkingSpot;

	// Use this for initialization
	void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Trigger")
        {
            print("This is: " + this.gameObject);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.name == "Trigger")
        {
            //MoveToParking();

            print("Atleast i tryed ");
        }
    }

   /* void MoveToParking()
    {
        iTween.MoveTo(this.gameObject, iTween.Hash("position", new Vector3(100,0,50), "speed", 20f, "easetype", iTween.EaseType.easeInOutSine));
    }*/
}
