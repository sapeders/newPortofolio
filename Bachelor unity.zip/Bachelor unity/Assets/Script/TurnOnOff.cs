﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnOnOff : MonoBehaviour
{
    public bool CarInside = false; 

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Car")
        {
            CarInside = true;
        }
        
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Car")
        {
            CarInside = false;
        }
    }
}