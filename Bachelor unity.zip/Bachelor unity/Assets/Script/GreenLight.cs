﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenLight : MonoBehaviour {

    public float timer;
    public Vector3 original;
	// Use this for initialization
	void Start () {
        original = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        timer += Time.deltaTime;

        if (timer > 20.0f)
        {
            transform.position += new Vector3(0, 100, 0);
        }
        if(timer > 35.0f)
        {
            timer = 0f;
            transform.position = original;
        }

	}
}
