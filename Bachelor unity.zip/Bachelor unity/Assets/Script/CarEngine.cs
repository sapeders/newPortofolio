﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CarEngine : MonoBehaviour {

    public Transform path;
    public Transform path1;
    public Transform path2;
    public Transform path3;
    public Transform path4;
    public Transform path5;
    public Transform path6;
    public Transform path7;
    public Transform path8;
    public Transform path9;
    public Transform path10;
    public Transform path11;
    public Transform path12;
    public Transform path13;
    public Transform path14;
    public Transform path15;
    public Transform path16;
    public Transform path17;
    public Transform path18;
    public Transform path19;
    public Transform path20;
    public float maxSteerAngle = 45;
    public float turnSpeed = 5;
    public WheelCollider wheelFL;
    public WheelCollider wheelFR;
    public WheelCollider wheelRL;
    public WheelCollider wheelRR;
    public float maxMotorTorque = 75;
    public float maxBrakeTorque = 1500;
    public float currentSpeed;
    public float maxSpeed = 100f;
    public Vector3 centerOfMass;
    public bool isBraking = false;
    public Texture2D textureNormal;
    public Texture2D textureBraking;
    public Texture2D textureParked;
    public Renderer carRenderer;

    public static bool park;

    [Header("Sensors")]
    public float sensorLength = 7f;    
    public Vector3 frontSensorPosition = new Vector3(0f, 0.2f, 0.5f);
    public float frontSideSensorPosition = 0.3f;
    

    private List<Transform> nodes;
    private int currectNode = 0;
    private bool braking = false;

    public Rigidbody rb;


    private void Start() {
        GetComponent<Rigidbody>().centerOfMass = centerOfMass;

        park = false;
        

        Transform[] pathTransforms = path.GetComponentsInChildren<Transform>();
        Transform[] path1Transforms = path1.GetComponentsInChildren<Transform>();
        Transform[] path2Transforms = path2.GetComponentsInChildren<Transform>();
        Transform[] path3Transforms = path3.GetComponentsInChildren<Transform>();
        Transform[] path4Transforms = path4.GetComponentsInChildren<Transform>();
        Transform[] path5Transforms = path5.GetComponentsInChildren<Transform>();
        Transform[] path6Transforms = path6.GetComponentsInChildren<Transform>();
        Transform[] path7Transforms = path7.GetComponentsInChildren<Transform>();
        Transform[] path8Transforms = path8.GetComponentsInChildren<Transform>();
        Transform[] path9Transforms = path9.GetComponentsInChildren<Transform>();
        Transform[] path10Transforms = path10.GetComponentsInChildren<Transform>();
        nodes = new List<Transform>();
        
        for (int i = 0; i < pathTransforms.Length; i++) {
            if (pathTransforms[i] != path.transform) {
                nodes.Add(pathTransforms[i]);
            }
        }

        for (int i = 0; i < path1Transforms.Length; i++)
        {
            if (path1Transforms[i] != path1.transform)
            {
                nodes.Add(path1Transforms[i]);
            }
        }

        for (int i = 0; i < path2Transforms.Length; i++)
        {
            if (path2Transforms[i] != path2.transform)
            {
                nodes.Add(path2Transforms[i]);
            }
        }

        for (int i = 0; i < path3Transforms.Length; i++)
        {
            if (path3Transforms[i] != path3.transform)
            {
                nodes.Add(path3Transforms[i]);
            }
        }

        for (int i = 0; i < path4Transforms.Length; i++)
        {
            if (path4Transforms[i] != path4.transform)
            {
                nodes.Add(path4Transforms[i]);
            }
        }

        for (int i = 0; i < path5Transforms.Length; i++)
        {
            if (path5Transforms[i] != path5.transform)
            {
                nodes.Add(path5Transforms[i]);
            }
        }

        for (int i = 0; i < path6Transforms.Length; i++)
        {
            if (path6Transforms[i] != path6.transform)
            {
                nodes.Add(path6Transforms[i]);
            }
        }

        for (int i = 0; i < path7Transforms.Length; i++)
        {
            if (path7Transforms[i] != path7.transform)
            {
                nodes.Add(path7Transforms[i]);
            }
        }

        for (int i = 0; i < path8Transforms.Length; i++)
        {
            if (path8Transforms[i] != path8.transform)
            {
                nodes.Add(path8Transforms[i]);
            }
        }

        for (int i = 0; i < path9Transforms.Length; i++)
        {
            if (path9Transforms[i] != path9.transform)
            {
                nodes.Add(path9Transforms[i]);
            }
        }

        for (int i = 0; i < path10Transforms.Length; i++)
        {
            if (path10Transforms[i] != path10.transform)
            {
                nodes.Add(path10Transforms[i]);
            }
        }

    }

    private void Update()
    {
        if (park == true)
        {
            Parked();
        }
        
    }

    private void FixedUpdate() {
        Sensors();
        ApplySteer();
        Drive();
        CheckWaypointDistance();
        Braking();
        //LerpToSteerAngle();
        
    }

    private void Sensors() {
        RaycastHit hit;
        Vector3 sensorStartPos = transform.position;
        sensorStartPos += transform.forward * frontSensorPosition.z;
        sensorStartPos += transform.up * frontSensorPosition.y;
        braking = false;
        
       

        //Front center sensor
        if(Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }
            
        }
        

        // Front right sensor
        sensorStartPos += transform.right * frontSideSensorPosition * 2;
        if (Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }
        }


        // Front left sensor
        sensorStartPos -= transform.right * frontSideSensorPosition * 2;
        if (Physics.Raycast(sensorStartPos, transform.forward, out hit, sensorLength))
        {
            if (!hit.collider.CompareTag("Terrain"))
            {
                braking = true;
                Debug.DrawLine(sensorStartPos, hit.point);
            }
        }

        if (braking)
        {
            isBraking = true;
        }
        else
        {
            isBraking = false;
        }


    }

    private void ApplySteer() {
       /* if (brake)
            isBraking = true;*/
        
        Vector3 relativeVector = transform.InverseTransformPoint(nodes[currectNode].position);
        float newSteer = (relativeVector.x / relativeVector.magnitude) * maxSteerAngle;
        wheelFL.steerAngle = newSteer;
        wheelFR.steerAngle = newSteer;
    }

    private void Drive() {
        currentSpeed = 2 * Mathf.PI * wheelFL.radius * wheelFL.rpm * 60 / 1000;

        if (currentSpeed < maxSpeed && !isBraking) {
            wheelFL.motorTorque = maxMotorTorque;
            wheelFR.motorTorque = maxMotorTorque;
        } else {
            wheelFL.motorTorque = 0;
            wheelFR.motorTorque = 0;
        }
    }

    private void CheckWaypointDistance() {
        if (Vector3.Distance(transform.position, nodes[currectNode].position) < 1f) {
            if (currectNode == nodes.Count - 1) {
                currectNode = 0;
            } else {
                currectNode++;
            }
        }
    }

    public void Parked()
    {
        //carRenderer.material.color = Color.green;
        Debug.Log("Parked");
    }

    private void Braking() {        
        if (isBraking) {
            carRenderer.material.mainTexture = textureBraking;
            wheelRL.brakeTorque = maxBrakeTorque;
            wheelRR.brakeTorque = maxBrakeTorque;
        } else {
            carRenderer.material.mainTexture = textureNormal;
            wheelRL.brakeTorque = 0;
            wheelRR.brakeTorque = 0;
        }
    }
    /*private void LerpToSteerAngle() {
        wheelFL.steerAngle = Mathf.Lerp(wheelFL.steerAngle, targetSteerAngle, Time.deltaTime * turnSpeed);
        wheelFR.steerAngle = Mathf.Lerp(wheelFR.steerAngle, targetSteerAngle, Time.deltaTime * turnSpeed);
    }*/
}
