﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnBlock : MonoBehaviour {

    public BoxCollider BC;
    
    private TurnOnOff script;
    

    void Start()
    {
        script = GameObject.Find("PathTuneveienNorth/Node (6)").GetComponent<TurnOnOff>();
        
    }

    void Update()
    {
        if(BC.isTrigger == true)
        {
            gameObject.tag = "Terrain";
        }
        else
        {
            gameObject.tag = "Untagged";
        }

        

        if (script.CarInside)
        {
            BC.isTrigger = false;
        }

        if (!script.CarInside)
        {
            BC.isTrigger = true;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        /*if ()
        {
            
        }
        else
        {
                        
        }*/
    }

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Car")
        {

        }

    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Car")
        {

        }
    }
}
