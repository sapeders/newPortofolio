﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnBlockE6Syk : MonoBehaviour {

    public BoxCollider rundE6Syk;
    private TurnOnOff rundkjoringSykehus;

    void Start()
    {
        rundkjoringSykehus = GameObject.Find("Time/RoundAbout/Street1LaneTurn90Deg (1)").GetComponent<TurnOnOff>();
    }

    void Update()
    {
        if(rundE6Syk.isTrigger == true)
        {
            gameObject.tag = "Terrain";
        }
        else
        {
            gameObject.tag = "Untagged";
        }

        if (rundkjoringSykehus.CarInside)
        {
            rundE6Syk.isTrigger = false;
        }

        if (!rundkjoringSykehus.CarInside)
        {
            rundE6Syk.isTrigger = true;
        }

    }

    void OnTriggerEnter(Collider other)
    {
        /*if ()
        {
            
        }
        else
        {
                        
        }*/
    }

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Car")
        {

        }

    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Car")
        {

        }
    }
}
