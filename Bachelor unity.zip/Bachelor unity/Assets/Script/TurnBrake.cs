﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnBrake : MonoBehaviour {


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
      

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Car")
        {
            if(other.GetComponent<NewCarEngine>().currentSpeed > 2)
            {
                other.GetComponent<NewCarEngine>().isBraking = true;
                other.GetComponent<NewCarEngine>().maxBrakeTorque = 1500;
                other.GetComponent<NewCarEngine>().rb.drag = 1;
            }
            else
            {
                other.GetComponent<NewCarEngine>().rb.drag = 0;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Car")
        {
            other.GetComponent<NewCarEngine>().isBraking = false;
            other.GetComponent<NewCarEngine>().maxBrakeTorque = 1500;
            other.GetComponent<NewCarEngine>().rb.drag = 0;
        }
    }

}
