﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cameras : MonoBehaviour {

    public Camera Kiwi;
    public Camera Politihuset;
    public Camera Tunesenter;
    public Camera Quality;
    public Camera Superland;
    public Camera Inspiria;
    public Camera K5;
    public Camera Caverion;
    public Camera freeMovement;

    private void Start()
    {
        Kiwi.enabled = true;
        Politihuset.enabled = false;
        Tunesenter.enabled = false;
        Quality.enabled = false;
        Superland.enabled = false;
        Inspiria.enabled = false;
        K5.enabled = false;
        Caverion.enabled = false;
        freeMovement.enabled = false;
    }

    // Update is called once per frame
    void Update ()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            Kiwi.enabled = true;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F2))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = true;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F3))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = true;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F4))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = true;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F5))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = true;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F6))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = true;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F7))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = true;
            Caverion.enabled = false;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F8))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = true;
            freeMovement.enabled = false;
        }
        if (Input.GetKeyDown(KeyCode.F9))
        {
            Kiwi.enabled = false;
            Politihuset.enabled = false;
            Tunesenter.enabled = false;
            Quality.enabled = false;
            Superland.enabled = false;
            Inspiria.enabled = false;
            K5.enabled = false;
            Caverion.enabled = false;
            freeMovement.enabled = true;
        }
        if (freeMovement.enabled == true)
        {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                freeMovement.transform.Translate(-5.0f * Time.deltaTime, 0.0f, 0.0f);
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                freeMovement.transform.Translate(+5.0f * Time.deltaTime, 0.0f, 0.0f);
            }
            if (Input.GetKey(KeyCode.PageUp))
            {
                freeMovement.transform.Translate(0.0f, 0.0f, +5.0f * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.PageDown))
            {
                freeMovement.transform.Translate(0.0f, 0.0f, -5.0f * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                freeMovement.transform.Translate(0.0f, -5.0f * Time.deltaTime, 0.0f);
            }
            if (Input.GetKey(KeyCode.UpArrow))
            {
                freeMovement.transform.Translate(0.0f, +5.0f * Time.deltaTime, 0.0f);
            }
        }
    }
}
