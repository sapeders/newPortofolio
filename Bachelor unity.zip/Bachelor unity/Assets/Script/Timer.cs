﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {

    private Text textBlock;
    private int hr;
    private int min;
    private int sec;

    // Use this for initialization
    void Start ()
    {
        textBlock = GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        DateTime time = DateTime.Now;

        sec = time.Second;

        if (sec == 60)
        {
            min++;
        }
        if(min == 60)
        {
            hr++;
        }

        textBlock.text = "0" + hr.ToString() + ":" + "0" + min.ToString() + ":" + sec.ToString();
    }
}
