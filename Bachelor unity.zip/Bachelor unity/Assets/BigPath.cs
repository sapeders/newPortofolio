﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigPath : MonoBehaviour {

    public Color lineColor;
    public bool taken;
    //private List<Transform> nodes = new List<Transform>();

    private void Start()
    {
        taken = false;
    }


}
