﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewTurnBrake : MonoBehaviour
{


  


    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Car")
        {
            if (other.GetComponent<NewCarEngine>().currentSpeed > 2)
            {
                other.GetComponent<NewCarEngine>().isBraking = true;
                other.GetComponent<NewCarEngine>().maxBrakeTorque = 1500;
                other.GetComponent<NewCarEngine>().rb.drag = 1;
            }
            else
            {
                other.GetComponent<NewCarEngine>().rb.drag = 0;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Car")
        {
            other.GetComponent<NewCarEngine>().isBraking = false;
            other.GetComponent<NewCarEngine>().maxBrakeTorque = 1500;
            other.GetComponent<NewCarEngine>().rb.drag = 0;
        }
    }

}

