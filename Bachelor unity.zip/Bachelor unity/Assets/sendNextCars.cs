﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sendNextCars : MonoBehaviour {
    public GameObject nextGroup;
    private int tmp;
    private void Start()
    {
        tmp = transform.childCount;

    }
    private void Update()
    {
        if (!transform.GetChild((tmp-1)).gameObject.activeInHierarchy)
        {
            nextGroup.SetActive(true);
        }
    }
}
