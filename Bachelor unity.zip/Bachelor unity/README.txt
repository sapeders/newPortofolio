Use f1, f2, f3 etc. to move between cameras.

Use "keypad +" to speed up the simulation, 
and "keypad -" to make it slower.

